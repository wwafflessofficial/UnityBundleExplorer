# Unity Bundle Explorer (Android starter project)

This is an Android Studio project for selecting a `data.unity3d` file through Android's document picker and inspecting its Unity bundle header.

## Important limitation
This starter project **does not yet extract Unity assets**. It reports bundle signature, Unity version, declared size and compression flags. Real extraction needs a UnityFS block-table parser, LZMA/LZ4 decompression, and a serialized Unity asset parser for extracting individual textures, meshes, audio and other objects. Unity bundle formats vary by Unity version and game, and some files may be encrypted or custom-wrapped.

## Build an APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Android Studio places the debug APK under `app/build/outputs/apk/debug/`.

Requires Android Studio and an installed Android SDK. The project targets Android 8.0+ (API 26+) and uses the system file picker, so it does not request broad storage access.

## Test
Launch the app, tap **Choose data.unity3d**, select the file, and read the header report.

Only inspect files you own or have permission to examine.


## Build on GitHub (no computer build tools needed locally)
1. Create a new repository on GitHub.
2. Upload the contents of this project folder to the repository root (so `settings.gradle`, `build.gradle`, and the `app` folder are at the top level).
3. Open the repository's **Actions** tab.
4. Choose **Build Unity Bundle Explorer APK** and press **Run workflow**. A push to the `main` branch also triggers a build.
5. When the run finishes, open the run and download the `UnityBundleExplorer-debug-apk` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.

This workflow builds a debug APK. The current app inspects bundle headers only; full asset extraction is not implemented yet.
