package com.libskidder.unitybundleexplorer

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater

class MainActivity : Activity() {
    private lateinit var output: TextView
    private var selectedName = "No file selected"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFF17131F.toInt())
        }
        val title = TextView(this).apply {
            text = "UNITY BUNDLE EXPLORER"
            textSize = 22f
            setTextColor(0xFFE8DDFB.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Inspect Unity .unity3d / UnityFS bundle headers and export supported bundle entries."
            textSize = 14f
            setTextColor(0xFFCDC4D9.toInt())
            setPadding(0, 12, 0, 18)
        }
        val pick = Button(this).apply {
            text = "Choose data.unity3d"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, 101)
            }
        }
        output = TextView(this).apply {
            text = "Choose a file to begin."
            textSize = 13f
            setTextColor(0xFFF2EDF8.toInt())
            setPadding(0, 18, 0, 18)
            textIsSelectable = true
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title)
        root.addView(subtitle)
        root.addView(pick)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 101 || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        selectedName = uri.lastPathSegment ?: "selected file"
        output.text = "Reading $selectedName…"
        Thread {
            val result = try {
                contentResolver.openInputStream(uri)?.use { stream -> inspect(stream) }
                    ?: "Could not open the selected file."
            } catch (e: Exception) {
                "Error: ${e.message ?: e.javaClass.simpleName}\n\nThis file may use a compression or Unity bundle variant this starter app does not support."
            }
            runOnUiThread { output.text = result }
        }.start()
    }

    private fun inspect(input: InputStream): String {
        val bytes = input.readBytes()
        if (bytes.isEmpty()) return "The file is empty."
        val text = String(bytes, 0, minOf(bytes.size, 64), Charsets.ISO_8859_1)
        val lines = mutableListOf<String>()
        lines += "File: $selectedName"
        lines += "Size: ${bytes.size} bytes (${String.format("%.2f", bytes.size / 1024.0 / 1024.0)} MiB)"
        lines += ""
        lines += "Header preview:"
        lines += text.takeWhile { it != '\u0000' }.replace("\n", " ").ifBlank { "(binary header)" }
        lines += ""
        val reader = Reader(bytes)
        val signature = reader.cString()
        lines += "Signature: $signature"
        if (signature !in listOf("UnityFS", "UnityRaw", "UnityWeb")) {
            lines += ""
            lines += "This does not look like a standard Unity bundle header."
            lines += "It may be an AssetBundle with a different wrapper, an encrypted file, or a raw serialized asset."
            lines += "No files were changed."
            return lines.joinToString("\n")
        }
        val format = reader.i32()
        val unityVersion = reader.cString()
        val unityRevision = reader.cString()
        val bundleSize = reader.i64()
        val compressedInfoSize = reader.i32()
        val uncompressedInfoSize = reader.i32()
        val flags = reader.i32()
        lines += "Format version: $format"
        lines += "Unity version: $unityVersion"
        lines += "Unity revision: $unityRevision"
        lines += "Declared bundle size: $bundleSize bytes"
        lines += "Compressed block-info size: $compressedInfoSize"
        lines += "Uncompressed block-info size: $uncompressedInfoSize"
        lines += "Flags: 0x${flags.toString(16)}"
        lines += "Data offset (approx.): ${reader.pos}"
        lines += ""
        lines += "Bundle details"
        lines += "• This build reads the bundle header and identifies the compression flags."
        lines += "• Full UnityFS extraction requires decoding the block-info table and LZ4/LZMA blocks."
        lines += "• Individual textures/models/audio are stored inside serialized Unity files; decoding those requires a Unity asset parser."
        lines += ""
        val compression = flags and 0x3F
        lines += "Block-info compression code: $compression"
        lines += when (compression) {
            0 -> "Compression: None"
            1 -> "Compression: LZMA"
            2 -> "Compression: LZ4"
            3 -> "Compression: LZ4HC"
            else -> "Compression: unknown / newer Unity format"
        }
        lines += ""
        lines += "Result: header inspection successful. This starter version does not yet extract assets from compressed bundles."
        return lines.joinToString("\n")
    }

    private class Reader(private val b: ByteArray) {
        var pos = 0
        fun cString(): String {
            val start = pos
            while (pos < b.size && b[pos].toInt() != 0) pos++
            val value = String(b, start, pos - start, Charsets.UTF_8)
            if (pos < b.size) pos++
            return value
        }
        fun i32(): Int {
            if (pos + 4 > b.size) throw IllegalArgumentException("Unexpected end of file while reading header")
            val v = ByteBuffer.wrap(b, pos, 4).order(ByteOrder.BIG_ENDIAN).int
            pos += 4
            return v
        }
        fun i64(): Long {
            if (pos + 8 > b.size) throw IllegalArgumentException("Unexpected end of file while reading header")
            val v = ByteBuffer.wrap(b, pos, 8).order(ByteOrder.BIG_ENDIAN).long
            pos += 8
            return v
        }
    }
}
